package sample;
import  javafx.animation.AnimationTimer;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.beans.property.ReadOnlyIntegerProperty;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Main extends Application {
    List<Tank> Tanks = new ArrayList<>();
    GraphicsContext gc;
    @Override
    public void start(Stage primaryStage) throws Exception {
        Canvas canvas = new Canvas(32*30,32*22);
        Image image =new Image("file:src/TowerDefense/AssetsKit_2/PNG/Retina/bg.png");
        Image image1 = new Image("file:src/TowerDefense/AssetsKit_2/PNG/Retina/xam.png");
        gc = canvas.getGraphicsContext2D();
        gc.drawImage(image,0,0,1000,700);
        Group root = new Group();
        Button button = new Button("NEW GAME");
        button.setLayoutX(450);
        button.setLayoutY(350);
        button.resize(50, 50);

        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Tower Defense");
        root.getChildren().addAll(canvas,button);
        primaryStage.show();
        //Tank a = new Tank();
        // GameManager manager = new GameManager();
        button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                gc.drawImage(image1,0,0,1000,1000);
                button.setVisible(false);
                drawMap(gc);
                AnimationTimer timer= new AnimationTimer() {
                    long timeOfLastFrameSwitch = 0;
                    @Override
                    public void handle(long now) {
                                render();
                                update();
                                //System.out.println(System.nanoTime()-timeOfLastFrameSwitch);
                                timeOfLastFrameSwitch = System.nanoTime();
                    }
                };
                timer.start();

                Tanks.add(createTank());
            }
        });

    }


    public Tank createTank(){
        Tank tank = new Tank();
        tank.im = new Image("file:src/TowerDefense/AssetsKit_2/PNG/Retina/231.png");
        return tank;
    }
    public static final String[][] MAP_SPRITES =new String[][]{
            { "024", "024", "024", "024", "024", "024", "003", "047", "047", "047","004", "024", "024", "024", "024", "024", "024", "024", "024", "024","024", "024", "024", "024", "024", "024", "024", "024", "024", "024" },
            { "047", "047", "047", "047", "004", "024", "025", "299", "001", "002","023", "024", "024", "024", "024", "024", "024", "024", "024", "024","024", "024", "024", "024", "024", "024", "024", "024", "024", "024" },
            { "001", "001", "001", "002", "023", "024", "025", "023", "024", "025","023", "024", "024", "024", "024", "024", "024", "024", "024", "024","024", "024", "024", "024", "024", "024", "024", "024", "024", "024" },
            { "024", "024", "024", "025", "023", "024", "025", "023", "024", "025","023", "024", "024", "024", "024", "024", "024", "024", "024", "024","024", "024", "024", "024", "024", "024", "024", "024", "024", "024" },
            { "024", "003", "047", "048", "023", "024", "025", "023", "024", "025","023", "024", "024", "024", "003", "047", "047", "047", "047", "047","047", "047", "047", "047", "047", "047", "047", "004", "024", "024" },
            { "024", "025", "299", "001", "027", "024", "025", "023", "024", "025","023", "024", "024", "024", "025", "299", "001", "001", "001", "001","001", "001", "001", "001", "001", "001", "002", "023", "024", "024" },
            { "024", "025", "023", "024", "024", "024", "025", "023", "024", "025","023", "024", "024", "024", "025", "023", "024", "024", "024", "024","024", "024", "024", "024", "024", "024", "025", "023", "024", "024" },
            { "024", "025", "046", "047", "047", "047", "048", "023", "024", "025","023", "024", "024", "024", "025", "023", "024", "024", "024", "024","024", "024", "024", "024", "024", "024", "025", "023", "024", "024" },
            { "024", "026", "001", "001", "001", "001", "001", "027", "024", "025","023", "024", "024", "024", "025", "023", "024", "024", "024", "024","024", "024", "024", "024", "024", "024", "025", "023", "024", "024" },
            { "024", "024", "024", "024", "024", "024", "024", "024", "024", "025","023", "024", "024", "024", "025", "023", "024", "024", "024", "024","024", "024", "024", "024", "024", "024", "025", "023", "024", "024" },
            { "024", "003", "047", "047", "047", "047", "004", "024", "024", "025","046", "047", "047", "047", "048", "023", "024", "024", "024", "024","024", "024", "024", "024", "024", "024", "025", "023", "024", "024" },
            { "024", "025", "299", "001", "001", "002", "023", "024", "024", "026","001", "001", "001", "001", "001", "027", "024", "024", "024", "024","024", "024", "024", "024", "024", "024", "025", "023", "024", "024" },
            { "024", "025", "023", "024", "024", "025", "023", "024", "024", "024","024", "024", "024", "024", "024", "024", "024", "024", "024", "024","024", "024", "024", "024", "024", "024", "025", "023", "024", "024" },
            { "024", "025", "023", "024", "024", "025", "046", "047", "047", "047","047", "047", "047", "047", "047", "047", "047", "047", "047", "047","047", "047", "047", "047", "047", "047", "048", "023", "024", "024" },
            { "024", "025", "023", "024", "024", "026", "001", "001", "001", "001","001", "001", "001", "001", "001", "001", "001", "001", "001", "001","001", "001", "001", "001", "001", "001", "001", "027", "024", "024" },
            { "024", "025", "023", "024", "024", "024", "024", "024", "024", "024","024", "024", "024", "024", "024", "024", "024", "024", "024", "024","024", "024", "024", "024", "024", "024", "024", "024", "024", "024" },
            { "024", "025", "023", "024", "024", "024", "024", "024", "024", "024","024", "024", "024", "024", "024", "024", "024", "024", "024", "024","024", "024", "024", "024", "024", "024", "024", "024", "024", "024" },
            { "024", "025", "023", "024", "024", "003", "047", "047", "047", "047","047", "047", "047", "047", "047", "047", "047", "047", "047", "047","047", "004", "024", "024", "024", "024", "024", "024", "024", "024" },
            { "024", "025", "023", "024", "024", "025", "299", "001", "001", "001","001", "001", "001", "001", "001", "001", "001", "001", "001", "001","002", "046", "047", "047", "047", "047", "047", "047", "047", "047" },
            { "024", "025", "046", "047", "047", "048", "023", "024", "024", "024","024", "024", "024", "024", "024", "024", "024", "024", "024", "024","026", "001", "001", "001", "001", "001", "001", "001", "001", "001" },
            { "024", "026", "001", "001", "001", "001", "027", "024", "024", "024","024", "024", "024", "024", "024", "024", "024", "024", "024", "024","024", "024", "024", "024", "024", "024", "024", "024", "024", "024" },
            { "024", "024", "024", "024", "024", "024", "024", "024", "024", "024","024", "024", "024", "024", "024", "024", "024", "024", "024", "024","024", "024", "024", "024", "024", "024", "024", "024", "024", "024" },
    };

    public void drawMap(GraphicsContext gc){
        for(int i=0;i< MAP_SPRITES.length;i++){
            for(int j=0;j<MAP_SPRITES[i].length;j++){
                gc.drawImage(new Image("file:src/TowerDefense/AssetsKit_2/PNG/Retina/towerDefense_tile" + MAP_SPRITES[i][j] + ".png"), j * 32,  i *32, 32,32 );
            }
        }
    }

    public void reDrawMap(GraphicsContext gc){
        Image image =new Image("file:src/TowerDefense/AssetsKit_2/PNG/Retina/remap.png");
        gc.drawImage(image,0,0,30*32,30*23);
    }

    public void render(){
        reDrawMap(gc);
        Tanks.forEach(g->g.Render(gc));
    }

    public void update(){
        for(int i=0;i<Tanks.size();i++) {
            //1
            if (Tanks.get(i).getX() < 3*32+16 && Tanks.get(i).getY() < 2*32+16) {
                Tanks.get(i).moveRight();
            }
            else if (Tanks.get(i).getDegree() < 450) {
                Tanks.forEach(g -> g.rotateUp());
                //2
            } else if (Tanks.get(i).getY() < 4*32+16 && Tanks.get(i).getX()>=3*32+20) {
                Tanks.forEach(g -> g.moveDown());
            } else if (Tanks.get(i).getDegree() < 540 && Tanks.get(i).getY() >= 130) {
                Tanks.forEach(g -> g.rotateUp());
                //3
            } else if (Tanks.get(i).getY() <= 4*32+20 && Tanks.get(i).getX() >= 1*32+16) {
                Tanks.forEach(g -> g.moveLeft());
             //else if (Tanks.get(i).getDegree() > 450 && Tanks.get(i).getX() >= 1*32+16) {
                //Tanks.forEach(g -> g.rotateDown());
                //4
            } else if (Tanks.get(i).getY() > 1*32+16&&Tanks.get(i).getY() <= 7*32+16) {
                Tanks.forEach(g -> g.moveDown());
                //5
            }else if (Tanks.get(i).getX() <= 6*32+16 && Tanks.get(i).getY()>=6*32+12 ) {
                Tanks.forEach(g -> g.moveRight());
                //6
            }else if (Tanks.get(i).getX() <=6*32+26 && Tanks.get(i).getY() > 16  && Tanks.get(i).getX()>=6*32+10){
                    Tanks.forEach(g -> g.moveUp());
            }
        }
    }
}
