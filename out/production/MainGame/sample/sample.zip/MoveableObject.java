package sample;

import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.transform.Rotate;

import java.util.ArrayList;
import java.util.List;

public class MoveableObject {
    int i ;
    int j ;
    int x = i*32 +16;
    int y = j*32 +50;
    Image im;
    double degree = 360;
    private double Rotate = 90;
    int speed = 5;

    void Render(GraphicsContext gc){
        SnapshotParameters param = new SnapshotParameters();
        param.setFill(Color.TRANSPARENT);
        ImageView iv = new ImageView(im);
        iv.setRotate(degree);
        Image image = iv.snapshot(param, null);
        gc.drawImage(image, x, y);
    }

    public void moveRight(){
        x+=speed;
    }
    public void moveDown(){
        y+=speed;
    }
    public void moveLeft(){
        x-=speed;
    }
    public void rotateDown(){
        degree -= 5;
    }
    public void rotateUp(){
        degree +=5;
    }

    public void setRotate(double rotate) {
        Rotate = rotate;
    }

    public double getRotate() {
        return Rotate;
    }

    public void moveUp(){y-=speed;}
    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
    public double getDegree() {
        return degree;
    }
}
