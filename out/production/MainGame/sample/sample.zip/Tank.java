package sample;

import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.transform.Rotate;

import java.util.ArrayList;
import java.util.List;

public class Tank extends MoveableObject {
    Image image;

    @Override
    public void moveUp() { super.moveUp(); }
    @Override
    public void rotateUp() {
        super.rotateUp();
    }

    @Override
    public void rotateDown() {
        super.rotateDown();
    }

    @Override
    public void moveDown() {
        super.moveDown();
    }

    @Override
    public void moveRight() {
        super.moveRight();
    }

    @Override
    public void moveLeft() {
        super.moveLeft();
    }

    @Override
    public double getRotate() {
        return super.getRotate();
    }

    @Override
    public void setRotate(double rotate) {
        super.setRotate(rotate);
    }
}
